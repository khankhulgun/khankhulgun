package config

import "testing"

var _ = func() bool {
	testing.Init()
	return true
}()