package utils

func AutoMigrateSeed() {

}
func seedData() {


}
